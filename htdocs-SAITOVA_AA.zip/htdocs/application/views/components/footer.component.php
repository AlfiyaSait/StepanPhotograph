<footer>
    <div class="container">
<!--        <h3>Подвал страницы --><?//=$footerTitle ?><!--</h3>-->
        <div class="footer-nav">
            <div><?php require 'nav.component.php'; ?></div>

        </div>
    </div>
</footer>
</body>
</html>
