<?php require "components/header.component.php"; ?>
<?php require "components/nav.component.php"; ?>
<main>

    <div class="sec8-text">
        <p>Я - АКТИВНЫЙ ПОЛЬЗОВАТЕЛЬ СОЦИАЛЬНЫХ СЕТЕЙ. ПОДПИСЫВАЙТЕСЬ!</p>
        <div class="icons-block">
            <a href="https://www.instagram.com/stepan_sviridoff/"><img src="images/icons/instagram_black_logo_icon.png" class="icons" alt="Instagram">
            </a>
            <a href="https://www.facebook.com/stepan.sviridov.56"><img src="images/icons/social_facebook_fb.png" class="icons" alt="Facebook">
            </a>
            <a href="https://vk.com/businesseasy"><img src="images/icons/free-icon-vkontakte.png" class="icons" alt="VKontakte">
            </a>
        </div>
        <p>8 (916) 393 69 61</p>
        <p>sviridoff1980@yandex.ru</p>
    </div>
</main>
<?php require "components/footer.component.php"; ?>

