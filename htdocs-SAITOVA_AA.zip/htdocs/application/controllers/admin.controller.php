<?php

$title = 'Администрирование';
$header = 'Администрирование';
$footerTitle = 'Администрирование';
require 'application/views/admin.view.php';

