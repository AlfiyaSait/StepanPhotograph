<?php
$title='Главная';
$header='Главная';
$footerTitle='Главная';
require 'application/views/index.view.php';
?>
