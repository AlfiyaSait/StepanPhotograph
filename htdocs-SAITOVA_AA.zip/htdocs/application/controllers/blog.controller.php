<?php
$title='Блог';
$header='Блог';
$footerTitle='Блог';
require 'application/views/blog.view.php';